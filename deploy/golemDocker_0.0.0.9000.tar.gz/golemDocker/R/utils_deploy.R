#' Dockerize
#'
#' @description Creates all necessary docker files
#'
#' @return None
#'
#' @noRd
dockerize <- function(ip = get_ip(), port = 5050, forward_port = NULL) {
  #
  if (is.null(forward_port)) {
    forward_port = port
  }

  message("Creating Dockerfiles...")
  devtools::load_all()
  golem::add_dockerfile_with_renv(host = ip, port = port)
  message("App dockerized...")
}

create_docker_image <- function() {
  message("Creating Dockerfiles...")
  devtools::load_all()
  golem::add_dockerfile_with_renv(host = ip, port = port)
  execute_cmd_commands(c(
    "cd deploy",
    "docker build -f Dockerfile_base --progress=plain -t golemdocker_base .",
    "docker build -f Dockerfile --progress=plain -t golemdocker:latest .",
    glue::glue("docker run -p {port}:{forward_port} golemdocker:latest")
  ))
  message("App dockerized...")
}

execute_cmd_commands__verbose <- function(commands) {
  message("Executed commands:")

  # Print Commands
  commands %>%
    purrr::map2_chr(
      1:length(.),
      .f = function(cmd, i, ...) {
        glue::glue(" => {i}. '{cmd}'")
      }
    ) %>%

    {
      for (cmd in .) {
        message(cmd)
      }
    }
}

execute_cmd_commands <- function(commands, verbose = FALSE) {
  if (verbose) {
    execute_cmd_commands__verbose(commands)
  }
  commands %>%
    paste(collapse = " && ") %>%
    shell()
}

get_ip <- function(select_wsl = FALSE) {
  config_info <- system("ipconfig", intern=TRUE)

  ip_addresses <- config_info[grep("IPv4", config_info)] %>%
    {
      gsub(".*? ([[:digit:]])", "\\1", .)
    }

  # Return ip
  if (select_wsl) {
    ip_addresses[2]
  } else {
    ip_addresses[1]
  }
}



